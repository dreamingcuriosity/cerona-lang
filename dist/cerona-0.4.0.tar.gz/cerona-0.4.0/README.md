---



[# Cerona](./ex)

Cerona is an unconventional esoteric programming language that takes a radical approach to language implementation: no parser, no lexer, no AST. Instead, it interprets code directly through string manipulation and token evaluation, making it a truly minimalist and experimental language.

Philosophy

Most programming languages follow a traditional architecture:

1. Lexer → tokenizes source code


2. Parser → builds an Abstract Syntax Tree (AST)


3. Interpreter/Compiler → executes the AST



Cerona throws this out the window. It reads your code as raw text, splits it into tokens on-the-fly, and executes commands immediately. This makes Cerona simultaneously primitive and fascinating — a language that lives on the edge between structured programming and pure text processing.

Features

✨ Zero traditional compilation phases — no lexer, parser, or AST

🔄 Dynamic variable system — variables are resolved at runtime

🧱 Experimental OOP — define classes and methods with class and new

🎯 Inline conditionals — if statements with then syntax

🔁 Loops — while and for constructs

📦 Functions — define and call user functions with parameters

💬 String handling — quote-aware parsing with escape sequences

🧮 Expression evaluation — arithmetic and logic through Python’s eval



---

Installation

pip install cerona

Or from source:

git clone https://github.com/dreamingcuriosity/cerona-lang.git
cd cerona-lang
pip install -e .


---

Usage

Create a .cerona file:

set x 10
set y 20
set sum x + y
print sum

if x less y then print "x is smaller"

set name "World"
print "Hello" name

Run it:

python -m cerona.main your_file.cerona


---

Syntax Guide

Variables

set variable_name value
set x 42
set message "Hello, Cerona!"
set result x + 10

Variables are dynamically typed and evaluated using Python expressions (sandboxed).


---

Printing

print value1 value2 value3
print x
print "The answer is" answer


---

Conditionals

if x equals 10 then print "x is ten"
if count greater 5 then set flag "active"

Supported operators:
equals, notequals, greater, less, greaterequals, lessequals, contains, in


---

Functions

func add a b
    set result a + b
    print result
endfunc

call add 5 10


---

Classes (Experimental OOP)

Cerona now has experimental class and object support — a very early form of object-oriented programming.

class Counter
    set count 0

    func init initial
        set count initial
    endfunc

    func increment
        set count count + 1
    endfunc

    func get_value
        print count
    endfunc
endclass

# Create instances
new Counter c1 0
new Counter c2 10

# Use methods
call c1.increment
call c1.increment
call c1.get_value  # prints 2
call c2.get_value  # prints 10

⚠️ Note:
OOP in Cerona is experimental. Attributes and method scopes work, but expression evaluation inside methods is limited — for instance, set count count + 2 may print literally as count + 2 instead of computing it.

You are, in effect, exploring the language while it’s still learning to be one.


---

Loops

set i 0
while i less 5
    print i
    set i i + 1
endwhile


---

Input

input username "Enter your name: "
print "Hello" username


---

How It Works — The Anti-Architecture

Cerona’s execution model is refreshingly simple:

1. Read the source as plain text


2. Split lines and tokenize dynamically


3. Execute each command immediately by pattern matching


4. Resolve variables at runtime


5. Repeat until end of file



No intermediate structures. No abstract syntax trees. Just direct interpretation.


---

Why Cerona?

Cerona is a love letter to absurd simplicity — an experiment in how little a language can have and still function. It’s not about performance or design purity; it’s about exploring the raw boundary between structure and chaos in language execution.

Perfect for:

🧠 Understanding how interpreters usually work — by omitting half the steps

🎨 Esolang enthusiasts

🧪 Experimental programmers

🤔 People who enjoy asking “What happens if I remove the parser?”



---

Limitations (By Design)

🧩 No complex parsing — nested expressions are fragile

💥 Limited error handling — expect cryptic messages

🌀 Dynamic everything — no type safety whatsoever

🧱 OOP quirks — expression evaluation in methods may not behave as expected

⚙️ Eval-based arithmetic — runs in a sandbox, but still limited


These aren’t bugs — they’re Cerona’s identity.


---

Contributing

Pull requests, bug reports, and philosophical arguments about “what even is a language” are all welcome.


---

"Why parse when you can just... not?" — The Cerona Philosophy
---
