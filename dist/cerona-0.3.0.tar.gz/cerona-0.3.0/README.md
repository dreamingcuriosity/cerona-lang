![Cerona](./1759642998581.jpg)

# Cerona

**Cerona** is an unconventional esoteric programming language that takes a radical approach to language implementation: **no parser, no lexer, no AST**. Instead, it interprets code directly through string manipulation and token evaluation, making it a truly minimalist and experimental language.

## Philosophy

Most programming languages follow a traditional architecture:
1. **Lexer** → tokenizes source code
2. **Parser** → builds an Abstract Syntax Tree (AST)
3. **Interpreter/Compiler** → executes the AST

Cerona throws this out the window. It reads your code as raw text, splits it into tokens on-the-fly, and executes commands immediately. This makes Cerona simultaneously primitive and fascinating—a language that lives on the edge between structured programming and pure text processing.

## Features

- ✨ **Zero traditional compilation phases** - no lexer, parser, or AST
- 🔄 **Dynamic variable system** - variables are resolved at runtime
- 🎯 **Inline conditionals** - `if` statements with `then` syntax
- 🔁 **Loops** - `while` and `for` constructs (implementation in progress)
- 📦 **Functions** - define and call functions with parameters
- 💬 **String handling** - quote-aware parsing with escape sequences
- 🧮 **Expression evaluation** - arithmetic and logic through Python's `eval`

## Installation

```bash
pip install cerona
```

Or install from source:

```bash
git clone https://github.com/dreamingcuriosity/cerona-lang.git
cd cerona-lang
pip install -e .
```

## Usage

Create a `.cerona` file (or any text file) with Cerona code:

```cerona
set x 10
set y 20
set sum x + y
print sum

if x less y then print "x is smaller"

set name "World"
print "Hello" name
```

Run it:

```bash
python -m cerona.main your_file.cerona
```

## Syntax Guide

### Variables

```cerona
set variable_name value
set x 42
set message "Hello, Cerona!"
set result x + 10
```

Variables are dynamically typed and evaluated using Python expressions.

### Printing

```cerona
print value1 value2 value3
print x
print "The answer is" answer
```

### Conditionals

```cerona
if condition operator value then command
if x equals 10 then print "x is ten"
if count greater 5 then set flag "active"
```

**Supported operators:**
- `equals` / `==`
- `notequals` / `!=`
- `greater` / `>`
- `greaterequals` / `>=`
- `less` / `<`
- `lessequals` / `<=`
- `contains` - check if right value is in left value
- `in` - check if left value is in right value

### Functions

```cerona
func add a b
    set result a + b
    return result
endfunc

call add 5 10
```

### Input

```cerona
input username "Enter your name: "
print "Hello" username
```

### Comments

Cerona uses shell-style comments:

```cerona
# This is a comment
set x 10  # Inline comment
```

## How It Works (The Anti-Architecture)

Cerona's execution model is refreshingly simple:

1. **Read** the entire source file as a string
2. **Split** lines and tokenize with quote awareness
3. **Execute** each command immediately by pattern matching on the first token
4. **Resolve** variables by looking them up in a dictionary
5. **Repeat** until the end of the file

No intermediate representations. No syntax trees. Just raw interpretation.

### Example Execution Flow

```cerona
set x 5
print x
```

1. Line 1: Token `["set", "x", "5"]` → Store `variables["x"] = 5`
2. Line 2: Token `["print", "x"]` → Lookup `variables["x"]` → Output `5`

That's it. No compilation, no AST traversal, just direct execution.

## Examples

### Hello World

```cerona
print "Hello, World!"
```

### Calculator

```cerona
input a "Enter first number: "
input b "Enter second number: "
set sum a + b
print "Sum:" sum
```

### Function Example

```cerona
func greet name
    print "Hello," name "!"
endfunc

call greet "Alice"
call greet "Bob"
```

### Conditional Logic

```cerona
input age "How old are you? "
if age greater 18 then print "You are an adult"
if age lessequals 18 then print "You are a minor"
```

## Limitations (By Design)

- **No complex parsing** - multiline expressions require workarounds
- **Limited error handling** - syntax errors may produce cryptic messages
- **No type system** - everything is evaluated dynamically
- **Eval-based expressions** - arithmetic uses Python's `eval()` (sandboxed)

These aren't bugs—they're features of Cerona's radical minimalism!

## Why Cerona?

Cerona is an experiment in language design minimalism. It asks: "What's the simplest possible way to execute code?" The answer isn't pretty, scalable, or fast—but it works, and it's fascinating to see how far you can get without the traditional compiler pipeline.

Perfect for:
- 🎓 Learning how interpreters work (by seeing what they usually do)
- 🧪 Experimenting with unconventional language design
- 🎨 Esolang enthusiasts and minimalism lovers
- 🤔 Understanding why parsers and ASTs exist in the first place

## Contributing

Contributions are welcome! Whether it's:
- Adding new commands
- Improving error messages
- Writing example programs
- Fixing bugs

Feel free to open issues or pull requests.

## License

See [LICENSE](./LICENSE) file for details.

## Acknowledgments

Cerona is an esoteric language experiment. It prioritizes conceptual simplicity over performance, safety, or conventional design. Use at your own risk (and amusement).

---

**"Why parse when you can just... not?"** - The Cerona Philosophy
